package jme3test.texture;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class TestRGB565 {

    public static void main(String[] args) throws IOException{
//        BufferedImage image = ImageIO.read(new File("C:\\hi.png"));
//        WritableRaster raster = colorModel.createCompatibleWritableRaster(image.getWidth(), image.getHeight());
//
//        BufferedImage newImage = new BufferedImage(colorModel, raster, false, null);
//
//        Graphics2D g = newImage.createGraphics();
//        g.drawImage(image, null, 0, 0);
//        g.dispose();
//
//        ImageIO.write(newImage, "png", new File("C:\\hi_low.png"));
    }

}
